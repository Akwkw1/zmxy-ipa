import SpriteKit
import UIKit

// ===== 造梦西游 · 原生 SpriteKit 复刻（素材全部来自原版 APK） =====

final class GameScene: SKScene {

    // ---------- 数据结构 ----------
    struct AnimInfo {
        let tex: [SKTexture]
        let footX: CGFloat
        let footY: CGFloat
        let w: CGFloat
        let h: CGFloat
        let count: Int
    }

    struct MobCfg {
        let hp: CGFloat
        let spd: CGFloat
        let dmg: CGFloat
        let scale: CGFloat
        let fly: Bool
        let ranged: Bool
        let boss: Bool
    }

    // ---------- 常量 ----------
    let worldW: CGFloat = 1280
    let worldH: CGFloat = 720
    let groundY: CGFloat = 120

    // ---------- 资源 ----------
    var anims: [String: AnimInfo] = [:]

    // ---------- 玩家 ----------
    var player = SKSpriteNode()
    var pX: CGFloat = 640
    var pY: CGFloat = 120
    var pVX: CGFloat = 0
    var pVY: CGFloat = 0
    var pOnGround = true
    var pFace: CGFloat = 1
    var pHP: CGFloat = 100
    var pMaxHP: CGFloat = 100
    var pDead = false
    var pInvuln: CGFloat = 0
    var pAtkCd: CGFloat = 0
    var pDashCd: CGFloat = 0
    var pFireCd: CGFloat = 0
    var pStormCd: CGFloat = 0
    var pDashT: CGFloat = 0
    var atkMul: CGFloat = 1
    var cdMul: CGFloat = 1
    var lifesteal: CGFloat = 0
    var crit: CGFloat = 0.05

    // ---------- 关卡 ----------
    struct Platform { let x: CGFloat; let y: CGFloat; let w: CGFloat; let h: CGFloat }
    var platforms: [Platform] = []

    // ---------- 敌人 ----------
    final class Enemy {
        var node = SKSpriteNode()
        var hp: CGFloat = 10
        var maxHP: CGFloat = 10
        var spd: CGFloat = 60
        var dmg: CGFloat = 8
        var fly = false
        var ranged = false
        var boss = false
        var cd: CGFloat = 0
        var dead = false
        var type: String = ""
        var animT: CGFloat = 0
        var state: String = "move"
        var flash: CGFloat = 0
    }
    var enemies: [Enemy] = []
    var enemyPool: [Enemy] = []

    // ---------- 子弹 ----------
    final class Bullet {
        var node = SKShapeNode()
        var vx: CGFloat = 0
        var vy: CGFloat = 0
        var dmg: CGFloat = 0
        var hostile = false
        var pierce = 0
        var life: CGFloat = 2
    }
    var bullets: [Bullet] = []
    var bulletPool: [Bullet] = []

    // ---------- 状态 ----------
    enum Phase { case intro, play, cards, dead }
    var phase: Phase = .intro
    var wave = 0
    var spawnLeft = 0
    var spawnT: CGFloat = 0
    var waveT: CGFloat = 0
    var kills = 0
    var mobTier = 2

    // ---------- 输入 ----------
    var joyActive = false
    var joyStart: CGPoint = .zero
    var joyNow: CGPoint = .zero
    var joyDX: CGFloat = 0

    // ---------- 节点 ----------
    let worldNode = SKNode()
    let hudNode = SKNode()
    var hpBar = SKSpriteNode()
    var hpBarBg = SKSpriteNode()
    var waveLabel = SKLabelNode(fontNamed: "PingFangSC-Semibold")
    var killLabel = SKLabelNode(fontNamed: "PingFangSC-Regular")
    var overlay: SKNode?

    // 按钮
    struct Btn { let key: String; let radius: CGFloat; let pos: CGPoint; var node: SKShapeNode; var icon: SKSpriteNode? }
    var buttons: [Btn] = []

    // ---------- 配置表 ----------
    let mobPool = ["niao", "daobing", "gongbing", "qiangbing", "gouyao", "yangyao", "niu", "shejing", "wugong", "heihu", "heigui"]
    let bossOrder = ["julingshen", "nantianwang", "beitianwang", "xitianwang", "zhuzizhen", "yangjian", "yuanhong"]

    let cfg: [String: MobCfg] = [
        "niao": MobCfg(hp: 26, spd: 96, dmg: 8, scale: 0.62, fly: true, ranged: false, boss: false),
        "daobing": MobCfg(hp: 42, spd: 76, dmg: 11, scale: 0.72, fly: false, ranged: false, boss: false),
        "gongbing": MobCfg(hp: 34, spd: 58, dmg: 9, scale: 0.70, fly: false, ranged: true, boss: false),
        "qiangbing": MobCfg(hp: 52, spd: 70, dmg: 13, scale: 0.72, fly: false, ranged: true, boss: false),
        "gouyao": MobCfg(hp: 50, spd: 92, dmg: 12, scale: 0.70, fly: false, ranged: false, boss: false),
        "yangyao": MobCfg(hp: 58, spd: 78, dmg: 12, scale: 0.72, fly: false, ranged: true, boss: false),
        "niu": MobCfg(hp: 98, spd: 62, dmg: 16, scale: 0.60, fly: false, ranged: false, boss: false),
        "shejing": MobCfg(hp: 64, spd: 88, dmg: 13, scale: 0.72, fly: false, ranged: false, boss: false),
        "wugong": MobCfg(hp: 92, spd: 86, dmg: 14, scale: 0.70, fly: false, ranged: false, boss: false),
        "heihu": MobCfg(hp: 112, spd: 98, dmg: 18, scale: 0.74, fly: false, ranged: false, boss: false),
        "heigui": MobCfg(hp: 146, spd: 50, dmg: 16, scale: 0.70, fly: false, ranged: true, boss: false),
        "qianliyan": MobCfg(hp: 320, spd: 72, dmg: 18, scale: 0.80, fly: false, ranged: true, boss: true),
        "shunfenger": MobCfg(hp: 320, spd: 86, dmg: 18, scale: 0.80, fly: false, ranged: false, boss: true),
        "wuying": MobCfg(hp: 360, spd: 104, dmg: 20, scale: 0.80, fly: false, ranged: false, boss: true),
        "xiaotianquan": MobCfg(hp: 400, spd: 96, dmg: 22, scale: 0.78, fly: false, ranged: false, boss: true),
        "julingshen": MobCfg(hp: 640, spd: 56, dmg: 22, scale: 0.82, fly: false, ranged: false, boss: true),
        "nantianwang": MobCfg(hp: 760, spd: 60, dmg: 24, scale: 0.84, fly: false, ranged: true, boss: true),
        "beitianwang": MobCfg(hp: 860, spd: 64, dmg: 25, scale: 0.84, fly: false, ranged: true, boss: true),
        "xitianwang": MobCfg(hp: 960, spd: 66, dmg: 26, scale: 0.84, fly: false, ranged: true, boss: true),
        "zhuzizhen": MobCfg(hp: 1080, spd: 74, dmg: 28, scale: 0.84, fly: false, ranged: true, boss: true),
        "yangjian": MobCfg(hp: 1260, spd: 78, dmg: 30, scale: 0.80, fly: false, ranged: true, boss: true),
        "yuanhong": MobCfg(hp: 1500, spd: 82, dmg: 32, scale: 0.82, fly: false, ranged: true, boss: true),
    ]

    // ================= 加载 =================
    override func didMove(to view: SKView) {
        backgroundColor = SKColor(red: 0.04, green: 0.06, blue: 0.09, alpha: 1)
        scaleMode = .aspectFit
        size = CGSize(width: worldW, height: worldH)
        anchorPoint = .zero

        addChild(worldNode)
        addChild(hudNode)

        platforms = [
            Platform(x: 0, y: 0, w: worldW, h: 120),
            Platform(x: 150, y: 250, w: 300, h: 26),
            Platform(x: 830, y: 250, w: 300, h: 26),
            Platform(x: 500, y: 380, w: 280, h: 26),
        ]

        loadAnimations()
        buildBackground()
        buildPlayer()
        buildHUD()
        showIntro()
    }

    func bundlePath(_ sub: String) -> String? {
        return Bundle.main.path(forResource: sub, ofType: nil)
    }

    func loadAnimations() {
        guard let jsonURL = Bundle.main.url(forResource: "animations", withExtension: "json", subdirectory: "www/assets/rogue"),
              let data = try? Data(contentsOf: jsonURL),
              let dict = (try? JSONSerialization.jsonObject(with: data)) as? [String: [String: Any]] else {
            return
        }
        for (name, meta) in dict {
            guard let w = meta["width"] as? NSNumber,
                  let h = meta["height"] as? NSNumber,
                  let count = meta["count"] as? NSNumber,
                  let cols = meta["columns"] as? NSNumber,
                  let fx = meta["footX"] as? NSNumber,
                  let fy = meta["footY"] as? NSNumber else { continue }

            guard let p = Bundle.main.path(forResource: name, ofType: "webp", inDirectory: "www/assets/rogue"),
                  let img = UIImage(contentsOfFile: p) else { continue }
            let sheet = SKTexture(image: img)

            let fw = CGFloat(truncating: w)
            let fh = CGFloat(truncating: h)
            let n = Int(truncating: count)
            let c = max(1, Int(truncating: cols))
            let rows = max(1, Int(ceil(Double(n) / Double(c))))
            let texW = sheet.size().width
            let texH = sheet.size().height
            guard texW > 0, texH > 0 else { continue }

            var frames: [SKTexture] = []
            frames.reserveCapacity(n)
            for i in 0..<n {
                let col = i % c
                let row = i / c
                let rect = CGRect(
                    x: CGFloat(col) * fw / texW,
                    y: 1.0 - CGFloat(row + 1) * fh / texH,
                    width: fw / texW,
                    height: fh / texH
                )
                frames.append(SKTexture(rect: rect, in: sheet))
            }
            _ = rows
            anims[name] = AnimInfo(tex: frames, footX: CGFloat(truncating: fx), footY: CGFloat(truncating: fy),
                                   w: fw, h: fh, count: n)
        }
        print("[ZMXY] loaded anims:", anims.count)
    }

    // ================= 背景 =================
    func buildBackground() {
        if let p = Bundle.main.path(forResource: "clouds", ofType: "webp", inDirectory: "www/assets/rogue"),
           let img = UIImage(contentsOfFile: p) {
            let sky = SKSpriteNode(texture: SKTexture(image: img))
            let s = max(worldW / img.size.width, worldH / img.size.height)
            sky.size = CGSize(width: img.size.width * s, height: img.size.height * s)
            sky.position = CGPoint(x: worldW / 2, y: worldH / 2)
            sky.zPosition = -100
            worldNode.addChild(sky)
        }
        var tileImg: UIImage? = nil
        if let p = Bundle.main.path(forResource: "arena_platform", ofType: "webp", inDirectory: "www/assets/rogue") {
            tileImg = UIImage(contentsOfFile: p)
        }
        for pf in platforms {
            if let img = tileImg {
                let node = SKSpriteNode(texture: SKTexture(image: img))
                node.size = CGSize(width: pf.w, height: pf.h + 16)
                node.position = CGPoint(x: pf.x + pf.w / 2, y: pf.y + pf.h / 2)
                node.zPosition = -50
                worldNode.addChild(node)
            } else {
                let node = SKSpriteNode(color: SKColor(red: 0.36, green: 0.29, blue: 0.18, alpha: 1),
                                        size: CGSize(width: pf.w, height: pf.h))
                node.position = CGPoint(x: pf.x + pf.w / 2, y: pf.y + pf.h / 2)
                node.zPosition = -50
                worldNode.addChild(node)
            }
        }
    }

    // ================= 玩家 =================
    func buildPlayer() {
        player = SKSpriteNode(texture: anims["hero_rest"]?.tex.first)
        player.size = CGSize(width: 114 * 1.15, height: 110 * 1.15)
        player.anchorPoint = CGPoint(x: 0.43, y: 0.02)
        player.position = CGPoint(x: pX, y: pY)
        player.zPosition = 10
        worldNode.addChild(player)
        playAnim(on: player, name: "hero_rest", repeatForever: true)
    }

    func playAnim(on node: SKSpriteNode, name: String, repeatForever: Bool = false) {
        guard let a = anims[name], !a.tex.isEmpty else { return }
        let dur = Double(a.count) * 0.07
        let act = SKAction.animate(with: a.tex, timePerFrame: 0.07)
        node.removeAction(forKey: "anim")
        node.run(repeatForever ? SKAction.repeatForever(act) : act, withKey: "anim")
        node.size = CGSize(width: a.w * (node.xScale == 0 ? 1 : 1), height: a.h)
    }

    // ================= HUD =================
    func buildHUD() {
        let panel = SKShapeNode(rectOf: CGSize(width: 340, height: 108), cornerRadius: 12)
        panel.fillColor = SKColor(white: 0.05, alpha: 0.45)
        panel.strokeColor = .clear
        panel.position = CGPoint(x: 190, y: worldH - 70)
        panel.zPosition = 100
        hudNode.addChild(panel)

        hpBarBg = SKSpriteNode(color: SKColor(white: 0.1, alpha: 0.8), size: CGSize(width: 300, height: 20))
        hpBarBg.anchorPoint = CGPoint(x: 0, y: 0.5)
        hpBarBg.position = CGPoint(x: 40, y: worldH - 50)
        hpBarBg.zPosition = 101
        hudNode.addChild(hpBarBg)

        hpBar = SKSpriteNode(color: SKColor(red: 0.85, green: 0.24, blue: 0.24, alpha: 1),
                             size: CGSize(width: 300, height: 20))
        hpBar.anchorPoint = CGPoint(x: 0, y: 0.5)
        hpBar.position = CGPoint(x: 40, y: worldH - 50)
        hpBar.zPosition = 102
        hudNode.addChild(hpBar)

        waveLabel.fontSize = 18
        waveLabel.fontColor = SKColor(red: 1, green: 0.91, blue: 0.69, alpha: 1)
        waveLabel.horizontalAlignmentMode = .left
        waveLabel.position = CGPoint(x: 40, y: worldH - 96)
        waveLabel.zPosition = 102
        hudNode.addChild(waveLabel)

        killLabel.fontSize = 14
        killLabel.fontColor = SKColor(white: 1, alpha: 0.75)
        killLabel.horizontalAlignmentMode = .left
        killLabel.position = CGPoint(x: 40, y: worldH - 118)
        killLabel.zPosition = 102
        hudNode.addChild(killLabel)

        // buttons
        let defs: [(String, CGFloat, CGPoint, String)] = [
            ("jump", 56, CGPoint(x: 1164, y: 190), ""),
            ("fire", 46, CGPoint(x: 1160, y: 66), "huoyanjinjing_icon"),
            ("dash", 46, CGPoint(x: 1030, y: 58), "huyantuji_icon"),
            ("storm", 46, CGPoint(x: 902, y: 50), "shenglongzhan_icon"),
        ]
        for (key, r, pos, icon) in defs {
            let n = SKShapeNode(circleOfRadius: r)
            n.fillColor = SKColor(white: 0.12, alpha: 0.55)
            n.strokeColor = SKColor(red: 1, green: 0.84, blue: 0.47, alpha: 0.85)
            n.lineWidth = 3
            n.position = pos
            n.zPosition = 100
            n.name = "btn_" + key
            hudNode.addChild(n)
            var iconNode: SKSpriteNode? = nil
            if !icon.isEmpty,
               let p = Bundle.main.path(forResource: icon, ofType: "png", inDirectory: "www/assets/skill_icons"),
               let img = UIImage(contentsOfFile: p) {
                let s = SKSpriteNode(texture: SKTexture(image: img))
                s.size = CGSize(width: r * 1.5, height: r * 1.5)
                s.position = pos
                s.zPosition = 101
                hudNode.addChild(s)
                iconNode = s
            } else {
                let l = SKLabelNode(fontNamed: "PingFangSC-Semibold")
                l.text = key == "jump" ? "跳" : ""
                l.fontSize = 24
                l.fontColor = SKColor(red: 1, green: 0.91, blue: 0.69, alpha: 1)
                l.verticalAlignmentMode = .center
                l.position = pos
                l.zPosition = 101
                hudNode.addChild(l)
            }
            buttons.append(Btn(key: key, radius: r, pos: pos, node: n, icon: iconNode))
        }
    }

    // ================= 流程 =================
    func showIntro() {
        let o = SKNode(); o.zPosition = 200
        let bg = SKSpriteNode(color: SKColor(red: 0.02, green: 0.04, blue: 0.07, alpha: 0.86),
                              size: CGSize(width: worldW, height: worldH))
        bg.position = CGPoint(x: worldW / 2, y: worldH / 2)
        o.addChild(bg)
        let t = SKLabelNode(fontNamed: "PingFangSC-Semibold")
        t.text = "造梦西游"
        t.fontSize = 66
        t.fontColor = SKColor(red: 1, green: 0.91, blue: 0.69, alpha: 1)
        t.position = CGPoint(x: worldW / 2, y: worldH / 2 + 40)
        o.addChild(t)
        let s = SKLabelNode(fontNamed: "PingFangSC-Regular")
        s.text = "原生复刻 · 点击开始"
        s.fontSize = 22
        s.fontColor = SKColor(white: 1, alpha: 0.8)
        s.position = CGPoint(x: worldW / 2, y: worldH / 2 - 40)
        o.addChild(s)
        o.name = "overlay"
        addChild(o)
        overlay = o
        phase = .intro
    }

    func startGame() {
        overlay?.removeFromParent(); overlay = nil
        pHP = 100; pMaxHP = 100; pDead = false
        pX = 640; pY = 120; pVX = 0; pVY = 0; pOnGround = true
        atkMul = 1; cdMul = 1; lifesteal = 0; crit = 0.05
        pAtkCd = 0; pDashCd = 0; pFireCd = 0; pStormCd = 0
        wave = 0; kills = 0; spawnLeft = 0; waveT = 0
        for e in enemies { e.node.removeFromParent() }
        enemies.removeAll()
        for b in bullets { b.node.removeFromParent() }
        bullets.removeAll()
        startWave()
    }

    func startWave() {
        wave += 1
        waveT = 0
        if wave % 5 == 0 {
            let bi = min(bossOrder.count - 1, max(0, wave / 5 - 1))
            spawn(bossOrder[bi])
            spawnLeft = 2 + wave / 5
            spawnT = 1.2
        } else {
            mobTier = min(mobPool.count, 2 + wave / 2)
            spawnLeft = min(6 + wave * 2, 18)
            spawnT = 0
        }
        phase = .play
    }

    // ================= 生成 =================
    func spawn(_ type: String) {
        guard let c = cfg[type] else { return }
        let e = enemyPool.popLast() ?? Enemy()
        e.type = type
        e.hp = c.hp * (1 + CGFloat(wave) * 0.14)
        e.maxHP = e.hp
        e.spd = c.spd * (1 + CGFloat(wave) * 0.02)
        e.dmg = c.dmg + CGFloat(wave) * 0.6
        e.fly = c.fly; e.ranged = c.ranged; e.boss = c.boss
        e.dead = false; e.cd = CGFloat.random(in: 0.4...1.4); e.state = "move"; e.flash = 0
        let fromLeft = Bool.random()
        let x: CGFloat = fromLeft ? -60 : worldW + 60
        let y: CGFloat = c.fly ? CGFloat.random(in: 320...560) : 120

        let node = SKSpriteNode()
        node.zPosition = e.boss ? 9 : 8
        worldNode.addChild(node)
        e.node.removeFromParent()
        e.node = node
        e.node.position = CGPoint(x: x, y: y)
        e.node.setScale(c.scale)
        applyAnim(e, "move")
        enemies.append(e)
    }

    func applyAnim(_ e: Enemy, _ key: String) {
        let base = e.type + "_" + key
        let fallback = e.type + "_move"
        let name = anims[base] != nil ? base : fallback
        guard let a = anims[name] else { return }
        e.node.size = CGSize(width: a.w, height: a.h)
        e.node.anchorPoint = CGPoint(x: a.footX / a.w, y: 1 - a.footY / a.h)
        let act = SKAction.repeatForever(SKAction.animate(with: a.tex, timePerFrame: 0.07))
        e.node.removeAction(forKey: "anim")
        e.node.run(act, withKey: "anim")
    }

    // ================= 输入 =================
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let t = touches.first else { return }
        let p = t.location(in: self)
        if phase == .intro || phase == .dead { startGame(); return }
        if phase == .cards { pickCard(at: p); return }
        if p.x < worldW * 0.45 {
            joyActive = true; joyStart = p; joyNow = p
            return
        }
        for b in buttons {
            if hypot(p.x - b.pos.x, p.y - b.pos.y) < b.radius * 1.3 {
                press(b.key)
                b.node.fillColor = SKColor(red: 1, green: 0.78, blue: 0.31, alpha: 0.75)
                return
            }
        }
    }

    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard joyActive, let t = touches.first else { return }
        joyNow = t.location(in: self)
    }

    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        joyActive = false; joyDX = 0
        for b in buttons { b.node.fillColor = SKColor(white: 0.12, alpha: 0.55) }
    }

    func press(_ key: String) {
        guard phase == .play, !pDead else { return }
        switch key {
        case "jump":
            if pOnGround { pVY = 900; pOnGround = false }
        case "dash":
            if pDashCd <= 0 { doDash() }
        case "fire":
            if pFireCd <= 0 { doFire() }
        case "storm":
            if pStormCd <= 0 { doStorm() }
        default: break
        }
    }

    // ================= 技能 =================
    func doDash() {
        pDashCd = 1.1 * cdMul
        pDashT = 0.22
        pInvuln = 0.28
        pX = min(max(pX + pFace * 210, 40), worldW - 40)
        for e in enemies where !e.dead {
            if hypot(e.node.position.x - pX, e.node.position.y - pY) < 170 {
                hurt(e, 14 * atkMul)
            }
        }
    }

    func doFire() {
        pFireCd = 1.5 * cdMul
        fireBullet(from: CGPoint(x: pX + pFace * 40, y: pY + 60), dir: pFace, dmg: 26 * atkMul, hostile: false, pierce: 3)
    }

    func doStorm() {
        pStormCd = 4.5 * cdMul
        for e in enemies where !e.dead {
            if hypot(e.node.position.x - pX, e.node.position.y - pY) < 190 {
                hurt(e, 40 * atkMul)
            }
        }
        let ring = SKShapeNode(circleOfRadius: 40)
        ring.strokeColor = SKColor(red: 1, green: 0.55, blue: 0.25, alpha: 0.9)
        ring.lineWidth = 8
        ring.position = CGPoint(x: pX, y: pY + 40)
        ring.zPosition = 20
        worldNode.addChild(ring)
        ring.run(SKAction.sequence([
            SKAction.group([
                SKAction.scale(to: 5.0, duration: 0.35),
                SKAction.fadeOut(withDuration: 0.35)
            ]),
            SKAction.removeFromParent()
        ]))
    }

    func fireBullet(from: CGPoint, dir: CGFloat, dmg: CGFloat, hostile: Bool, pierce: Int = 0) {
        let b = bulletPool.popLast() ?? Bullet()
        b.node.removeFromParent()
        let n = SKShapeNode(circleOfRadius: 10)
        n.fillColor = hostile ? SKColor(red: 0.8, green: 0.35, blue: 1, alpha: 1)
                              : SKColor(red: 1, green: 0.85, blue: 0.35, alpha: 1)
        n.strokeColor = .clear
        n.glowWidth = 8
        n.position = from
        n.zPosition = 15
        worldNode.addChild(n)
        b.node = n
        b.vx = dir * 720; b.vy = 0; b.dmg = dmg; b.hostile = hostile
        b.pierce = pierce; b.life = 1.6
        bullets.append(b)
    }

    // ================= 战斗 =================
    func hurt(_ e: Enemy, _ dmg: CGFloat) {
        guard !e.dead else { return }
        e.hp -= dmg
        e.flash = 0.12
        let isCrit = CGFloat.random(in: 0...1) < crit
        let shown = Int(isCrit ? dmg * 1.8 : dmg)
        floatText("\(shown)", at: e.node.position, crit: isCrit)
        if lifesteal > 0 { pHP = min(pMaxHP, pHP + dmg * lifesteal) }
        if e.hp <= 0 {
            e.dead = true
            kills += 1
            e.node.run(SKAction.sequence([
                SKAction.fadeOut(withDuration: 0.35),
                SKAction.removeFromParent()
            ]))
        }
    }

    func hurtPlayer(_ dmg: CGFloat) {
        guard !pDead, pInvuln <= 0 else { return }
        pHP -= dmg
        pInvuln = 0.75
        let flash = SKAction.sequence([SKAction.fadeAlpha(to: 0.35, duration: 0.06),
                                       SKAction.fadeAlpha(to: 1.0, duration: 0.06)])
        player.run(flash)
        if pHP <= 0 { pHP = 0; pDead = true; gameOver() }
    }

    func floatText(_ s: String, at pos: CGPoint, crit: Bool) {
        let l = SKLabelNode(fontNamed: "PingFangSC-Bold")
        l.text = s
        l.fontSize = crit ? 26 : 20
        l.fontColor = crit ? SKColor(red: 1, green: 0.82, blue: 0.29, alpha: 1) : .white
        l.position = CGPoint(x: pos.x, y: pos.y + 70)
        l.zPosition = 30
        worldNode.addChild(l)
        l.run(SKAction.sequence([
            SKAction.group([SKAction.moveBy(x: 0, y: 60, duration: 0.7),
                            SKAction.fadeOut(withDuration: 0.7)]),
            SKAction.removeFromParent()
        ]))
    }

    // ================= 卡牌 =================
    var cardChoices: [(String, () -> Void)] = []

    func showCards() {
        phase = .cards
        let pool: [(String, () -> Void)] = [
            ("攻击 +25%", { [weak self] in self?.atkMul *= 1.25 }),
            ("生命上限 +30", { [weak self] in self?.pMaxHP += 30; self?.pHP += 30 }),
            ("技能冷却 -18%", { [weak self] in self?.cdMul *= 0.82 }),
            ("吸血 +12%", { [weak self] in self?.lifesteal += 0.12 }),
            ("暴击率 +12%", { [weak self] in self?.crit += 0.12 }),
            ("回满生命", { [weak self] in self?.pHP = self?.pMaxHP ?? 100 }),
        ]
        var picked: [(String, () -> Void)] = []
        var p2 = pool
        for _ in 0..<3 {
            let k = Int.random(in: 0..<p2.count)
            picked.append(p2.remove(at: k))
        }
        cardChoices = picked

        let o = SKNode(); o.zPosition = 200
        let bg = SKSpriteNode(color: SKColor(red: 0.02, green: 0.04, blue: 0.07, alpha: 0.78),
                              size: CGSize(width: worldW, height: worldH))
        bg.position = CGPoint(x: worldW / 2, y: worldH / 2)
        o.addChild(bg)
        let t = SKLabelNode(fontNamed: "PingFangSC-Semibold")
        t.text = "选一张强化"; t.fontSize = 40
        t.fontColor = SKColor(red: 1, green: 0.91, blue: 0.69, alpha: 1)
        t.position = CGPoint(x: worldW / 2, y: worldH - 180)
        o.addChild(t)

        let cw: CGFloat = 250, ch: CGFloat = 300, gap: CGFloat = 40
        let total = CGFloat(picked.count) * cw + CGFloat(picked.count - 1) * gap
        var x = (worldW - total) / 2
        for (i, c) in picked.enumerated() {
            let card = SKShapeNode(rectOf: CGSize(width: cw, height: ch), cornerRadius: 18)
            card.fillColor = SKColor(red: 0.15, green: 0.22, blue: 0.34, alpha: 1)
            card.strokeColor = SKColor(red: 0.5, green: 0.66, blue: 0.84, alpha: 1)
            card.lineWidth = 3
            card.position = CGPoint(x: x + cw / 2, y: 330)
            card.name = "card_\(i)"
            o.addChild(card)
            let l = SKLabelNode(fontNamed: "PingFangSC-Semibold")
            l.text = c.0
            l.fontSize = 24
            l.fontColor = SKColor(red: 1, green: 0.91, blue: 0.69, alpha: 1)
            l.position = card.position
            l.verticalAlignmentMode = .center
            l.name = "card_\(i)"
            o.addChild(l)
            x += cw + gap
        }
        o.name = "overlay"
        addChild(o)
        overlay = o
    }

    func pickCard(at p: CGPoint) {
        guard let o = overlay else { return }
        for n in o.children {
            if let name = n.name, name.hasPrefix("card_"),
               n.frame.contains(p) {
                let idx = Int(name.split(separator: "_").last ?? "0") ?? 0
                if idx < cardChoices.count {
                    cardChoices[idx].1()
                    o.removeFromParent(); overlay = nil
                    phase = .play
                    startWave()
                }
                return
            }
        }
    }

    func gameOver() {
        phase = .dead
        let o = SKNode(); o.zPosition = 200
        let bg = SKSpriteNode(color: SKColor(red: 0.03, green: 0.01, blue: 0.01, alpha: 0.8),
                              size: CGSize(width: worldW, height: worldH))
        bg.position = CGPoint(x: worldW / 2, y: worldH / 2)
        o.addChild(bg)
        let t = SKLabelNode(fontNamed: "PingFangSC-Semibold")
        t.text = "身 陨"; t.fontSize = 60
        t.fontColor = SKColor(red: 1, green: 0.48, blue: 0.42, alpha: 1)
        t.position = CGPoint(x: worldW / 2, y: worldH / 2 + 40)
        o.addChild(t)
        let s = SKLabelNode(fontNamed: "PingFangSC-Regular")
        s.text = "坚持到第 \(wave) 波 · 击杀 \(kills) · 点击重来"
        s.fontSize = 22
        s.position = CGPoint(x: worldW / 2, y: worldH / 2 - 40)
        o.addChild(s)
        o.name = "overlay"
        addChild(o)
        overlay = o
    }

    // ================= 主循环 =================
    var lastT: TimeInterval = 0

    override func update(_ currentTime: TimeInterval) {
        var dt = CGFloat(currentTime - lastT)
        lastT = currentTime
        if dt <= 0 || dt > 0.1 { dt = 1.0 / 60.0 }
        guard phase == .play else { return }

        // 玩家移动
        var ax: CGFloat = 0
        if joyActive {
            let dx = joyNow.x - joyStart.x
            if abs(dx) > 12 { ax = max(-1, min(1, dx / 60)) }
        }
        if ax != 0 { pFace = ax > 0 ? 1 : -1 }
        pVX += (ax * 330 - pVX) * min(1, dt * 12)
        if pDashT > 0 { pDashT -= dt; pVX = pFace * 900 }
        pX = min(max(pX + pVX * dt, 30), worldW - 30)

        let prevY = pY
        pVY -= 2400 * dt
        pY += pVY * dt
        if pY <= 120 { pY = 120; pVY = 0; pOnGround = true } else { pOnGround = false }
        _ = prevY

        player.position = CGPoint(x: pX, y: pY)
        player.xScale = pFace < 0 ? -1 : 1

        // 冷却
        pAtkCd -= dt; pDashCd -= dt; pFireCd -= dt; pStormCd -= dt; pInvuln -= dt
        if pDashT > 0 { pInvuln = max(pInvuln, 0.05) }

        // 自动普攻
        if pAtkCd <= 0 {
            var best: Enemy? = nil; var bd: CGFloat = 1e9
            for e in enemies where !e.dead {
                let d = hypot(e.node.position.x - pX, e.node.position.y - pY)
                if d < bd, (e.node.position.x - pX) * pFace > 0 { bd = d; best = e }
            }
            if let e = best, bd < 150 {
                pAtkCd = 0.42
                let names = ["hero_attack_1", "hero_attack_2", "hero_attack_3"]
                let nm = names.randomElement()!
                if let a = anims[nm] {
                    player.removeAction(forKey: "anim")
                    player.run(SKAction.sequence([
                        SKAction.animate(with: a.tex, timePerFrame: 0.05),
                        SKAction.run { [weak self] in self?.playAnim(on: self?.player ?? SKSpriteNode(), name: "hero_rest", repeatForever: true) }
                    ]), withKey: "anim")
                }
                hurt(e, 16 * atkMul)
                spawnSlash(at: e.node.position)
            }
        }

        // 生成
        if phase == .play {
            spawnT -= dt
            if spawnLeft > 0 && spawnT <= 0 && enemies.filter({ !$0.dead }).count < 20 {
                let pool = Array(mobPool.prefix(max(1, mobTier)))
                spawn(pool.randomElement() ?? "niao")
                spawnLeft -= 1
                spawnT = max(0.25, 0.85 - CGFloat(wave) * 0.03)
            }
        }

        // 敌人 AI
        for e in enemies where !e.dead {
            let dx = pX - e.node.position.x
            let dy = (pY + 40) - e.node.position.y
            let d = hypot(dx, dy)
            e.node.xScale = (dx > 0 ? 1 : -1) * (e.boss ? 0.82 : 1)
            if e.fly {
                let ty = pY + 90 + sin(currentTime * 2) * 26
                e.node.position.y += (ty - e.node.position.y) * min(1, dt * 2.2)
                e.node.position.x += (dx > 0 ? 1 : -1) * e.spd * dt
                if d < 70 && e.cd <= 0 { e.cd = 1.1; hurtPlayer(e.dmg * 0.7) }
            } else {
                if d > 60 { e.node.position.x += (dx > 0 ? 1 : -1) * e.spd * dt }
                e.node.position.x = min(max(e.node.position.x, -80), worldW + 80)
                if d < 70 && e.cd <= 0 { e.cd = 1.2; hurtPlayer(e.dmg) }
                if e.ranged && d < 520 && e.cd <= 0 {
                    e.cd = 1.8
                    fireBullet(from: e.node.position, dir: dx > 0 ? 1 : -1, dmg: e.dmg, hostile: true)
                }
            }
            e.cd -= dt
        }

        // 子弹
        for b in bullets {
            b.node.position.x += b.vx * dt
            b.node.position.y += b.vy * dt
            b.life -= dt
            if b.life <= 0 {
                b.node.removeFromParent(); b.life = -1; continue
            }
            if b.hostile {
                if hypot(b.node.position.x - pX, b.node.position.y - (pY + 40)) < 34 {
                    hurtPlayer(b.dmg); b.node.removeFromParent(); b.life = -1
                }
            } else {
                for e in enemies where !e.dead {
                    if hypot(b.node.position.x - e.node.position.x, b.node.position.y - e.node.position.y) < 40 {
                        hurt(e, b.dmg)
                        if b.pierce > 0 { b.pierce -= 1 } else { b.node.removeFromParent(); b.life = -1 }
                        break
                    }
                }
            }
        }
        bullets.removeAll { $0.life < 0 }

        // 波次
        waveT += dt
        let alive = enemies.contains { !$0.dead }
        if !alive && spawnLeft == 0 && waveT > 0.8 {
            if wave % 3 == 0 { showCards() } else { startWave() }
        }

        // HUD
        hpBar.xScale = max(0, pHP / pMaxHP)
        waveLabel.text = "第 \(wave) 波"
        killLabel.text = "击杀 \(kills)"
        for b in buttons {
            var cd: CGFloat = 0
            switch b.key {
            case "dash": cd = max(0, pDashCd / (1.1 * cdMul))
            case "fire": cd = max(0, pFireCd / (1.5 * cdMul))
            case "storm": cd = max(0, pStormCd / (4.5 * cdMul))
            default: break
            }
            b.node.alpha = cd > 0 ? 0.45 : 1.0
            b.icon?.alpha = cd > 0 ? 0.45 : 1.0
        }
    }

    func spawnSlash(at p: CGPoint) {
        let s = SKShapeNode(circleOfRadius: 26)
        s.strokeColor = SKColor(red: 1, green: 0.9, blue: 0.6, alpha: 0.9)
        s.lineWidth = 5
        s.position = p
        s.zPosition = 20
        worldNode.addChild(s)
        s.run(SKAction.sequence([
            SKAction.group([SKAction.scale(to: 2.0, duration: 0.18),
                            SKAction.fadeOut(withDuration: 0.18)]),
            SKAction.removeFromParent()
        ]))
    }
}
