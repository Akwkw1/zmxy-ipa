'use strict';
// ===== 造梦西游 · 网页复刻版 =====
const VW = 1280, VH = 720, GROUND = 640;
const cvs = document.getElementById('c');
const ctx = cvs.getContext('2d', { alpha: false, desynchronized: true });
let DPR = 1, scaleFactor = 1;

const IMGS = {}, ANIM = window.ANIM || {};
const SPR = {};
for (const k in ANIM) SPR[k] = 'assets/rogue/' + k + '.webp';
const BG = { clouds: null, arena: null };
const ICONS = { dash: null, fire: null, storm: null };
const ICON_SRC = {
  dash: 'assets/skill_icons/lieyanshan_icon.png',
  fire: 'assets/skill_icons/huoyanjinjing_icon.png',
  storm: 'assets/skill_icons/shenglongzhan_icon.png'
};
let loadLeft = 0, loaded = false;

function boot() {
  const keys = Object.keys(SPR);
  loadLeft = keys.length + 2;
  for (const k of keys) {
    const img = new Image();
    img.onload = img.onerror = () => { if (--loadLeft <= 0) loaded = true; };
    img.src = SPR[k];
    IMGS[k] = img;
  }
  const c = new Image();
  c.onload = c.onerror = () => { if (--loadLeft <= 0) loaded = true; };
  c.src = 'assets/rogue/clouds.webp'; BG.clouds = c;
  const a = new Image();
  a.onload = a.onerror = () => { if (--loadLeft <= 0) loaded = true; };
  a.src = 'assets/rogue/arena_platform.webp'; BG.arena = a;
  loadLeft += 3;
  for (const k of Object.keys(ICON_SRC)) {
    const im = new Image();
    im.onload = im.onerror = () => { if (--loadLeft <= 0) loaded = true; };
    im.src = ICON_SRC[k];
    ICONS[k] = im;
  }
}

// ---------- resize ----------
function resize() {
  const w = window.innerWidth, h = window.innerHeight;
  const s = Math.min(w / VW, h / VH);
  const cssW = VW * s, cssH = VH * s;
  DPR = Math.min(window.devicePixelRatio || 1, 2);
  cvs.style.width = cssW + 'px';
  cvs.style.height = cssH + 'px';
  cvs.style.left = (w - cssW) / 2 + 'px';
  cvs.style.top = (h - cssH) / 2 + 'px';
  cvs.width = Math.round(VW * s * DPR);
  cvs.height = Math.round(VH * s * DPR);
  scaleFactor = cvs.width / VW;
  ctx.setTransform(scaleFactor, 0, 0, scaleFactor, 0, 0);
  ctx.imageSmoothingEnabled = true;
  bgDirty = true;
}
window.addEventListener('resize', resize);

// ---------- helpers ----------
const rnd = (a, b) => a + Math.random() * (b - a);
const clamp = (v, a, b) => v < a ? a : (v > b ? b : v);
const dist = (x1, y1, x2, y2) => Math.hypot(x1 - x2, y1 - y2);

// ---------- sprite draw ----------
function drawSheet(name, frame, x, y, sc, flip, alpha) {
  const a = ANIM[name], img = IMGS[name];
  if (!a || !img || !img.width) return;
  const n = a.count;
  const f = ((frame | 0) % n + n) % n;
  const cx = f % a.columns, cy = (f / a.columns) | 0;
  const sx = cx * a.width, sy = cy * a.height;
  ctx.save();
  if (alpha !== undefined) ctx.globalAlpha = alpha;
  ctx.translate(x, y);
  if (flip) ctx.scale(-sc, sc); else ctx.scale(sc, sc);
  ctx.drawImage(img, sx, sy, a.width, a.height, -a.footX, -a.footY, a.width, a.height);
  ctx.restore();
}

// ---------- background (cached) ----------
let bgCanvas = null, bgDirty = true;
function makeGlow(r, g, b) {
  const cv = document.createElement('canvas'); cv.width = cv.height = 64;
  const c2 = cv.getContext('2d');
  const gr = c2.createRadialGradient(32, 32, 0, 32, 32, 32);
  gr.addColorStop(0, 'rgba(255,255,255,1)');
  gr.addColorStop(0.35, 'rgba(' + r + ',' + g + ',' + b + ',0.95)');
  gr.addColorStop(1, 'rgba(' + r + ',' + g + ',' + b + ',0)');
  c2.fillStyle = gr; c2.fillRect(0, 0, 64, 64);
  return cv;
}
const GLOW_P = makeGlow(255, 170, 60);
const GLOW_H = makeGlow(220, 90, 255);
const CLOUDS = [];
for (let i = 0; i < 14; i++) CLOUDS.push({ x: rnd(-200, VW + 200), y: rnd(40, 320), s: rnd(0.4, 1.3), v: rnd(4, 14) });

function buildBG() {
  bgCanvas = document.createElement('canvas');
  bgCanvas.width = VW; bgCanvas.height = VH;
  const g = bgCanvas.getContext('2d');
  g.fillStyle = '#16243a'; g.fillRect(0, 0, VW, VH);

  // sky artwork (cover)
  const sky = BG.clouds;
  if (sky && sky.width) {
    const s = Math.max(VW / sky.width, VH / sky.height);
    const w = sky.width * s, h = sky.height * s;
    g.drawImage(sky, (VW - w) / 2, (VH - h) / 2, w, h);
  }

  // ground + platforms using arena_platform texture
  const tile = BG.arena;
  for (const p of PLATFORMS) {
    g.save();
    g.beginPath(); g.rect(p.x, p.y, p.w, p.h); g.clip();
    if (tile && tile.width) {
      if (p.w > 900) {
        // ground: stretch a single strip so it stays continuous
        g.drawImage(tile, 0, Math.round(tile.height * 0.55), tile.width, Math.round(tile.height * 0.45),
                    p.x, p.y, p.w, p.h);
      } else {
        const th = p.h + 16, tw = th * (tile.width / tile.height);
        for (let x = p.x - tw * 0.35; x < p.x + p.w; x += tw * 0.96) {
          g.drawImage(tile, 0, 0, tile.width, tile.height, x, p.y - 8, tw, th);
        }
      }
    } else {
      g.fillStyle = '#5b4a2f'; g.fillRect(p.x, p.y, p.w, p.h);
    }
    g.fillStyle = 'rgba(0,0,0,0.28)';
    g.fillRect(p.x, p.y + p.h - 10, p.w, 10);
    g.fillStyle = 'rgba(255,238,200,0.22)';
    g.fillRect(p.x, p.y, p.w, 3);
    g.restore();
  }
  // bottom falloff
  const grd = g.createLinearGradient(0, VH - 60, 0, VH);
  grd.addColorStop(0, 'rgba(6,10,18,0)'); grd.addColorStop(1, 'rgba(6,10,18,0.85)');
  g.fillStyle = grd; g.fillRect(0, VH - 60, VW, 60);
  bgDirty = false;
}

// ---------- world ----------
const PLATFORMS = [
  { x: 0, y: GROUND, w: VW, h: 80 },        // ground
  { x: 150, y: 470, w: 300, h: 22 },
  { x: 830, y: 470, w: 300, h: 22 },
  { x: 500, y: 350, w: 280, h: 22 },
];

function surfaceAt(x, y, prevY) {
  let best = GROUND;
  for (const p of PLATFORMS) {
    if (x > p.x - 6 && x < p.x + p.w + 6) {
      if (prevY <= p.y + 4 && y >= p.y) { if (p.y < best) best = p.y; }
    }
  }
  return best;
}

// ---------- pools ----------
function makePool(n, factory) {
  const a = new Array(n);
  for (let i = 0; i < n; i++) a[i] = factory();
  return a;
}
const bullets = makePool(220, () => ({ on: false, x: 0, y: 0, vx: 0, vy: 0, r: 8, dmg: 0, life: 0, hostile: false, pierce: 0, color: '#ff9a3c', sprite: null, anim: 0 }));
const particles = makePool(260, () => ({ on: false, x: 0, y: 0, vx: 0, vy: 0, life: 0, max: 1, size: 3, color: '#fff', grav: 0 }));
const floaters = makePool(80, () => ({ on: false, x: 0, y: 0, vy: 0, life: 0, text: '', color: '#fff', size: 22 }));
const enemies = makePool(40, () => ({ on: false, type: null, x: 0, y: 0, vx: 0, vy: 0, hp: 0, maxHp: 0, face: 1, anim: 0, animT: 0, state: 'move', t: 0, cd: 0, onGround: false, boss: false, hurt: 0, dead: 0, flash: 0 }));

function spawnParticle(x, y, vx, vy, life, size, color, grav) {
  for (const p of particles) if (!p.on) {
    p.on = true; p.x = x; p.y = y; p.vx = vx; p.vy = vy; p.life = life; p.max = life; p.size = size; p.color = color; p.grav = grav || 0;
    return;
  }
}
function spawnFloater(x, y, text, color, size) {
  for (const f of floaters) if (!f.on) {
    f.on = true; f.x = x; f.y = y; f.vy = -70; f.life = 0.85; f.text = text; f.color = color; f.size = size || 22;
    return;
  }
}
function spawnBullet(o) {
  for (const b of bullets) if (!b.on) { Object.assign(b, o); b.on = true; b.life = o.life || 1.6; return b; }
  return null;
}

// ---------- player ----------
const P = {
  x: 640, y: GROUND, vx: 0, vy: 0, onGround: true, face: 1,
  hp: 100, maxHp: 100, mp: 100, maxMp: 100,
  anim: 'hero_rest', frame: 0, animT: 0,
  atkCd: 0, atkAnim: 0, combo: 0,
  dashCd: 0, dashT: 0, fireCd: 0, stormCd: 0,
  invuln: 0, hurtFlash: 0, dead: false, deadT: 0,
  moveX: 0, jumpBuf: 0,
  atkMul: 1, hpMul: 1, cdMul: 1, lifesteal: 0, crit: 0.05, critMul: 2,
};

// ---------- game state ----------
const G = {
  wave: 0, waveT: 0, phase: 'intro', // intro | play | cards | dead | win
  spawnLeft: 0, spawnT: 0, killCount: 0,
  cards: [], cardSel: 0,
  time: 0, shake: 0,
  score: 0,
};

// ---------- input ----------
const touch = { joyId: -1, joyX: 0, joyY: 0, joyOX: 0, joyOY: 0, active: false };
const buttons = [
  { id: 'jump', label: '跳', x: 1164, y: 534, r: 56, cd: 0, on: false },
  { id: 'fire', label: '火眼', x: 1152, y: 664, r: 45, cd: 0, on: false },
  { id: 'dash', label: '烈焰闪', x: 1026, y: 672, r: 45, cd: 0, on: false },
  { id: 'storm', label: '升龙', x: 900, y: 676, r: 45, cd: 0, on: false },
];

function toWorld(cx, cy) {
  const r = cvs.getBoundingClientRect();
  return { x: (cx - r.left) / r.width * VW, y: (cy - r.top) / r.height * VH };
}

let tapStart = null;
cvs.addEventListener('touchstart', e => {
  e.preventDefault();
  if (G.phase !== 'play') { const t0 = e.changedTouches[0]; tapStart = { x: t0.clientX, y: t0.clientY, t: performance.now() }; }
  for (const t of e.changedTouches) {
    const p = toWorld(t.clientX, t.clientY);
    if (p.x < VW * 0.45) {
      touch.joyId = t.identifier; touch.joyOX = p.x; touch.joyOY = p.y;
      touch.joyX = p.x; touch.joyY = p.y; touch.active = true;
    } else {
      for (const b of buttons) {
        if (dist(p.x, p.y, b.x, b.y) < b.r * 1.35) { pressButton(b.id); b.on = true; }
      }
    }
  }
}, { passive: false });

cvs.addEventListener('touchmove', e => {
  e.preventDefault();
  for (const t of e.changedTouches) {
    if (t.identifier === touch.joyId) {
      const p = toWorld(t.clientX, t.clientY);
      touch.joyX = p.x; touch.joyY = p.y;
    }
  }
}, { passive: false });

cvs.addEventListener('touchend', e => {
  e.preventDefault();
  for (const t of e.changedTouches) {
    if (t.identifier === touch.joyId) { touch.joyId = -1; touch.active = false; }
  }
  for (const b of buttons) b.on = false;
  if (tapStart) {
    const t0 = e.changedTouches[0];
    if (Math.hypot(t0.clientX - tapStart.x, t0.clientY - tapStart.y) < 24 && performance.now() - tapStart.t < 600) {
      handleTap(t0.clientX, t0.clientY);
    }
    tapStart = null;
  }
}, { passive: false });

const keys = {};
window.addEventListener('keydown', e => {
  keys[e.code] = true;
  if (e.code === 'Space') pressButton('jump');
  if (e.code === 'KeyJ') pressButton('dash');
  if (e.code === 'KeyK') pressButton('fire');
  if (e.code === 'KeyL') pressButton('storm');
  if (G.phase === 'cards') {
    if (e.code === 'Digit1') pickCard(0);
    if (e.code === 'Digit2') pickCard(1);
    if (e.code === 'Digit3') pickCard(2);
  }
  if (e.code === 'Enter' && (G.phase === 'dead')) startGame();
});
window.addEventListener('keyup', e => { keys[e.code] = false; });

function pressButton(id) {
  if (G.phase !== 'play' || P.dead) return;
  if (id === 'jump') { if (P.onGround) { P.vy = -980; P.onGround = false; P.jumpBuf = 0.12; } }
  else if (id === 'dash' && P.dashCd <= 0) { doDash(); }
  else if (id === 'fire' && P.fireCd <= 0) { doFire(); }
  else if (id === 'storm' && P.stormCd <= 0) { doStorm(); }
}

// ---------- skills ----------
function doDash() {
  P.dashCd = 1.1 * P.cdMul; P.dashT = 0.22; P.invuln = 0.26;
  const dir = P.face;
  for (let i = 0; i < 10; i++) spawnParticle(P.x - dir * 20, P.y - 40 + rnd(-14, 14), -dir * rnd(120, 320), rnd(-60, 60), 0.4, rnd(2, 5), '#ffb347', 0);
  for (const e of enemies) {
    if (!e.on || e.dead) continue;
    const d = dist(P.x, P.y - 40, e.x, e.y);
    if (d < 170) hurtEnemy(e, damageOf(14), dir);
  }
  P.x = clamp(P.x + dir * 210, 40, VW - 40);
}
function doFire() {
  P.fireCd = 1.5 * P.cdMul;
  P.anim = 'hero_hytj'; P.animT = 0; P.atkAnim = 0.18;
  spawnBullet({ x: P.x + P.face * 34, y: P.y - 52, vx: P.face * 760, vy: 0, r: 14, dmg: damageOf(26), hostile: false, pierce: 3, sprite: 'fire', life: 1.4, color: '#ffdd55' });
  for (let i = 0; i < 6; i++) spawnParticle(P.x + P.face * 34, P.y - 52, P.face * rnd(60, 200), rnd(-80, 80), 0.3, rnd(2, 4), '#ffdd55', 0);
}
function doStorm() {
  P.stormCd = 4.5 * P.cdMul;
  P.anim = 'hero_slz'; P.animT = 0; P.atkAnim = 0.3;
  G.shake = 0.25;
  for (let i = 0; i < 26; i++) {
    const a = i / 26 * Math.PI * 2;
    spawnParticle(P.x, P.y - 40, Math.cos(a) * rnd(120, 380), Math.sin(a) * rnd(120, 380) - 60, 0.55, rnd(3, 7), '#ff7a3c', 120);
  }
  for (const e of enemies) {
    if (!e.on || e.dead) continue;
    if (dist(P.x, P.y - 40, e.x, e.y) < 190) hurtEnemy(e, damageOf(40), Math.sign(e.x - P.x) || 1);
  }
}

function damageOf(base) {
  let d = base * P.atkMul;
  const isCrit = Math.random() < P.crit;
  if (isCrit) d *= P.critMul;
  return { v: d, crit: isCrit };
}

function hurtEnemy(e, dmg, dir) {
  if (e.dead) return;
  const v = typeof dmg === 'number' ? dmg : dmg.v;
  const crit = typeof dmg === 'object' && dmg.crit;
  e.hp -= v;
  e.flash = 0.12;
  e.vx += dir * 90;
  spawnFloater(e.x + rnd(-8, 8), e.y - 70, (crit ? '暴击 ' : '') + Math.round(v), crit ? '#ffd24a' : '#ffffff', crit ? 26 : 20);
  for (let i = 0; i < 4; i++) spawnParticle(e.x, e.y - 40, rnd(-160, 160), rnd(-200, -40), 0.35, rnd(2, 4), '#ff6b4a', 400);
  if (P.lifesteal > 0) { P.hp = Math.min(P.maxHp, P.hp + v * P.lifesteal); }
  if (e.hp <= 0) {
    e.dead = 1; e.t = 0; e.state = 'death';
    G.killCount++; G.score += e.boss ? 200 : 10;
    for (let i = 0; i < (e.boss ? 26 : 10); i++) spawnParticle(e.x, e.y - 40, rnd(-260, 260), rnd(-320, -60), 0.6, rnd(2, 6), e.boss ? '#ffb347' : '#ff8a5c', 500);
  }
}

// ---------- enemy spawn ----------
const TYPES = {
  // ---- 小怪 ----
  niao:      { hp: 26, spd: 96, dmg: 8,  sc: 0.62, fly: true },
  daobing:   { hp: 42, spd: 76, dmg: 11, sc: 0.72 },
  gongbing:  { hp: 34, spd: 58, dmg: 9,  sc: 0.70, ranged: true },
  qiangbing: { hp: 52, spd: 70, dmg: 13, sc: 0.72, ranged: true },
  gouyao:    { hp: 50, spd: 92, dmg: 12, sc: 0.70 },
  yangyao:   { hp: 58, spd: 78, dmg: 12, sc: 0.72, ranged: true },
  niu:       { hp: 98, spd: 62, dmg: 16, sc: 0.60 },
  shejing:   { hp: 64, spd: 88, dmg: 13, sc: 0.72 },
  wugong:    { hp: 92, spd: 86, dmg: 14, sc: 0.70 },
  heihu:     { hp: 112, spd: 98, dmg: 18, sc: 0.74 },
  heigui:    { hp: 146, spd: 50, dmg: 16, sc: 0.70, ranged: true },
  // ---- 精英 ----
  qianliyan:   { hp: 320, spd: 72, dmg: 18, sc: 0.80, boss: true, ranged: true },
  shunfenger:  { hp: 320, spd: 86, dmg: 18, sc: 0.80, boss: true },
  wuying:      { hp: 360, spd: 104, dmg: 20, sc: 0.80, boss: true },
  xiaotianquan:{ hp: 400, spd: 96, dmg: 22, sc: 0.78, boss: true },
  // ---- 天王 / 最终 Boss ----
  julingshen:  { hp: 640, spd: 56, dmg: 22, sc: 0.82, boss: true },
  nantianwang: { hp: 760, spd: 60, dmg: 24, sc: 0.84, boss: true, ranged: true },
  beitianwang: { hp: 860, spd: 64, dmg: 25, sc: 0.84, boss: true, ranged: true },
  xitianwang:  { hp: 960, spd: 66, dmg: 26, sc: 0.84, boss: true, ranged: true },
  zhuzizhen:   { hp: 1080, spd: 74, dmg: 28, sc: 0.84, boss: true, ranged: true },
  yangjian:    { hp: 1260, spd: 78, dmg: 30, sc: 0.80, boss: true, ranged: true },
  yuanhong:    { hp: 1500, spd: 82, dmg: 32, sc: 0.82, boss: true, ranged: true },
};

const MOB_POOL = ['niao', 'daobing', 'gongbing', 'qiangbing', 'gouyao', 'yangyao', 'niu', 'shejing', 'wugong', 'heihu', 'heigui'];
const BOSS_ORDER = ['julingshen', 'nantianwang', 'beitianwang', 'xitianwang', 'zhuzizhen', 'yangjian', 'yuanhong'];

function sheetSet(fam) {
  const s = {};
  for (const k of ['move', 'attack', 'hurt', 'death', 'rest', 'skill', 'bullet_1']) {
    const n = fam + '_' + k;
    if (ANIM[n]) s[k === 'bullet_1' ? 'bullet' : k] = n;
  }
  if (!s.move && s.rest) s.move = s.rest;
  return s;
}

function spawnEnemy(typeKey) {
  const T = TYPES[typeKey];
  for (const e of enemies) if (!e.on) {
    e.on = true; e.type = typeKey; e.t = 0; e.cd = rnd(0.4, 1.4);
    e.boss = !!T.boss; e.dead = 0; e.hurt = 0; e.flash = 0; e.state = 'move';
    e.maxHp = Math.round(T.hp * (1 + G.wave * 0.14));
    e.hp = e.maxHp;
    e.sc = T.sc;
    e.fly = !!T.fly;
    e.ranged = !!T.ranged;
    e.dmg = T.dmg + G.wave * 0.6;
    e.spd = T.spd * (1 + G.wave * 0.02);
    e.sheets = sheetSet(typeKey);
    const left = Math.random() < 0.5;
    e.x = left ? -60 : VW + 60;
    e.y = e.fly ? rnd(180, 380) : GROUND;
    e.vy = 0; e.onGround = !e.fly;
    e.face = left ? 1 : -1;
    e.animT = 0; e.anim = 0;
    return e;
  }
  return null;
}

function startWave() {
  G.wave++;
  G.waveT = 0;
  const isBoss = G.wave % 5 === 0;
  if (isBoss) {
    const bi = Math.min(BOSS_ORDER.length - 1, Math.floor(G.wave / 5) - 1);
    spawnEnemy(BOSS_ORDER[bi]);
    G.spawnLeft = 2 + Math.floor(G.wave / 5);
    G.spawnT = 1.2;
  } else {
    const tier = Math.min(MOB_POOL.length, 2 + Math.floor(G.wave / 2));
    G.mobTier = tier;
    G.spawnLeft = Math.min(6 + G.wave * 2, 20);
    G.spawnT = 0;
  }
  G.phase = 'play';
}

// ---------- cards ----------
const CARD_POOL = [
  { t: '攻击 +25%', f: () => P.atkMul *= 1.25 },
  { t: '生命上限 +30', f: () => { P.maxHp += 30; P.hp += 30; } },
  { t: '技能冷却 -18%', f: () => P.cdMul *= 0.82 },
  { t: '吸血 +12%', f: () => P.lifesteal += 0.12 },
  { t: '暴击率 +12%', f: () => P.crit += 0.12 },
  { t: '暴击伤害 +50%', f: () => P.critMul += 0.5 },
  { t: '回满生命', f: () => { P.hp = P.maxHp; } },
  { t: '攻击 +15% & 生命 +15', f: () => { P.atkMul *= 1.15; P.maxHp += 15; P.hp += 15; } },
];
function showCards() {
  const pool = CARD_POOL.slice();
  G.cards = [];
  for (let i = 0; i < 3 && pool.length; i++) {
    const k = (Math.random() * pool.length) | 0;
    G.cards.push(pool.splice(k, 1)[0]);
  }
  G.phase = 'cards';
}
function pickCard(i) {
  if (G.phase !== 'cards') return;
  const c = G.cards[i]; if (!c) return;
  c.f();
  G.phase = 'idle';
  setTimeout(() => { if (!P.dead) startWave(); }, 120);
}

// ---------- update ----------
function update(dt) {
  G.time += dt;
  if (G.shake > 0) G.shake -= dt;

  // ---- player ----
  if (!P.dead) {
    let ax = 0;
    if (touch.active) {
      const dx = touch.joyX - touch.joyOX, dy = touch.joyY - touch.joyOY;
      const m = Math.hypot(dx, dy);
      if (m > 12) { ax = clamp(dx / 60, -1, 1); }
    }
    if (keys['KeyA'] || keys['ArrowLeft']) ax = -1;
    if (keys['KeyD'] || keys['ArrowRight']) ax = 1;
    P.moveX = ax;
    if (Math.abs(ax) > 0.1) P.face = ax > 0 ? 1 : -1;

    const speed = 330;
    P.vx += (ax * speed - P.vx) * Math.min(1, dt * 12);
    if (P.dashT > 0) { P.dashT -= dt; P.vx = P.face * 900; }
    P.x = clamp(P.x + P.vx * dt, 30, VW - 30);

    // gravity
    const prevY = P.y;
    P.vy += 2400 * dt;
    P.y += P.vy * dt;
    const surf = surfaceAt(P.x, P.y, prevY);
    if (P.y >= surf) { P.y = surf; P.vy = 0; P.onGround = true; } else P.onGround = false;

    if (P.invuln > 0) P.invuln -= dt;
    if (P.atkCd > 0) P.atkCd -= dt;
    if (P.atkAnim > 0) P.atkAnim -= dt;
    if (P.dashCd > 0) P.dashCd -= dt;
    if (P.fireCd > 0) P.fireCd -= dt;
    if (P.stormCd > 0) P.stormCd -= dt;
    if (P.dashT > 0) P.invuln = Math.max(P.invuln, 0.05);

    // auto attack
    if (P.atkCd <= 0 && G.phase === 'play') {
      let near = null, nd = 1e9;
      for (const e of enemies) {
        if (!e.on || e.dead) continue;
        const d = dist(P.x, P.y - 40, e.x, e.y);
        if (d < nd && Math.sign(e.x - P.x) === P.face) { nd = d; near = e; }
      }
      if (near && nd < 150) {
        P.atkCd = 0.42; P.atkAnim = 0.22;
        P.anim = 'hero_attack_' + (1 + ((Math.random() * 3) | 0));
        hurtEnemy(near, damageOf(16), P.face);
      }
    }

    // anim
    if (P.atkAnim > 0) { P.animT += dt; }
    else if (!P.onGround) { P.anim = 'hero_jumpdown'; P.animT += dt; }
    else if (Math.abs(P.vx) > 40) { P.anim = 'hero_run'; P.animT += dt * (Math.abs(P.vx) / 240); }
    else { P.anim = 'hero_rest'; P.animT += dt; }
  } else {
    P.deadT += dt;
    if (P.deadT > 1.6 && G.phase !== 'dead') G.phase = 'dead';
  }

  // ---- spawning ----
  if (G.phase === 'play') {
    G.spawnT -= dt;
    if (G.spawnLeft > 0 && G.spawnT <= 0 && aliveCount() < 22) {
      const pool = MOB_POOL.slice(0, Math.max(1, G.mobTier || 2));
      const pick = pool[(Math.random() * pool.length) | 0];
      spawnEnemy(pick);
      G.spawnLeft--;
      G.spawnT = Math.max(0.25, 0.85 - G.wave * 0.03);
    }
  }

  // ---- enemies ----
  for (const e of enemies) {
    if (!e.on) continue;
    e.t += dt;
    if (e.flash > 0) e.flash -= dt;
    if (e.dead) {
      e.animT += dt;
      if (e.t > 0.9) { e.on = false; }
      continue;
    }
    const T = TYPES[e.type];
    const dx = P.x - e.x, dy = (P.y - 40) - e.y;
    const d = Math.hypot(dx, dy);
    e.face = dx > 0 ? 1 : -1;

    if (e.fly) {
      const targetY = (P.y - 90) + Math.sin(e.t * 2) * 26;
      e.y += (targetY - e.y) * Math.min(1, dt * 2.2);
      e.x += Math.sign(dx) * e.spd * dt * (d > 60 ? 1 : 0.2);
      if (d < 60 && e.cd <= 0) { e.cd = 1.1; hitPlayer(e.dmg * 0.8); }
    } else {
      if (d > 46) e.x += Math.sign(dx) * e.spd * dt;
      e.x = clamp(e.x, -80, VW + 80);
      if (d < 52 && e.cd <= 0) {
        e.cd = 1.2;
        e.state = 'attack'; e.animT = 0;
        hitPlayer(e.dmg);
      }
      if (e.ranged && d < 520 && e.cd <= 0) {
        e.cd = 1.8;
        e.state = 'attack'; e.animT = 0;
        const ang = Math.atan2(dy, dx);
        spawnBullet({ x: e.x + e.face * 20, y: e.y - 46, vx: Math.cos(ang) * 360, vy: Math.sin(ang) * 360, r: 7, dmg: e.dmg, hostile: true, life: 2.4, color: '#c86bff' });
      }
    }
    if (e.cd > 0) e.cd -= dt;
    if (e.state === 'attack') { e.animT += dt; if (e.animT > 0.45) e.state = 'move'; }
    else e.animT += dt;
    // face player y check for boss
    if (e.boss && e.cd <= 0 && d < 700) {
      e.cd = 2.6 + Math.random();
      const ang = Math.atan2(dy, dx);
      for (let k = -1; k <= 1; k++) {
        spawnBullet({ x: e.x, y: e.y - 70, vx: Math.cos(ang + k * 0.28) * 330, vy: Math.sin(ang + k * 0.28) * 330, r: 12, dmg: e.dmg * 0.8, hostile: true, life: 3, color: '#ff6b6b' });
      }
      for (let i = 0; i < 8; i++) spawnParticle(e.x, e.y - 70, rnd(-120, 120), rnd(-120, 120), 0.4, rnd(2, 5), '#ff9a6b', 0);
    }
  }

  // ---- bullets ----
  for (const b of bullets) {
    if (!b.on) continue;
    b.x += b.vx * dt; b.y += b.vy * dt; b.life -= dt;
    if (b.life <= 0 || b.x < -60 || b.x > VW + 60 || b.y < -60 || b.y > VH + 60) { b.on = false; continue; }
    if (b.hostile) {
      if (!P.dead && dist(b.x, b.y, P.x, P.y - 40) < b.r + 26) { hitPlayer(b.dmg); b.on = false; }
    } else {
      for (const e of enemies) {
        if (!e.on || e.dead) continue;
        if (dist(b.x, b.y, e.x, e.y - 40) < b.r + 26) {
          hurtEnemy(e, { v: b.dmg, crit: Math.random() < P.crit }, Math.sign(b.vx) || 1);
          if (b.pierce > 0) b.pierce--; else { b.on = false; break; }
        }
      }
    }
  }

  // ---- particles ----
  for (const p of particles) {
    if (!p.on) continue;
    p.life -= dt;
    if (p.life <= 0) { p.on = false; continue; }
    p.vy += p.grav * dt;
    p.x += p.vx * dt; p.y += p.vy * dt;
  }
  for (const f of floaters) {
    if (!f.on) continue;
    f.life -= dt; f.y += f.vy * dt; f.vy += 60 * dt;
    if (f.life <= 0) f.on = false;
  }

  // ---- wave / phase ----
  if (G.phase === 'play') {
    const alive = enemies.some(e => e.on && !e.dead);
    if (!alive && G.spawnLeft === 0 && G.waveT > 0.6) {
      if (G.wave % 3 === 0) { showCards(); }
      else startWave();
    }
    G.waveT += dt;
  }
  if (buttons) for (const b of buttons) b.cd = 0;

  // sync skill CD display
  buttons[1].cd = Math.max(0, P.dashCd / (1.1 * P.cdMul));
  buttons[2].cd = Math.max(0, P.fireCd / (1.5 * P.cdMul));
  buttons[3].cd = Math.max(0, P.stormCd / (4.5 * P.cdMul));
}

function hitPlayer(dmg) {
  if (P.dead || P.invuln > 0) return;
  P.hp -= dmg;
  P.invuln = 0.75; P.hurtFlash = 0.25;
  G.shake = 0.18;
  spawnFloater(P.x, P.y - 90, '-' + Math.round(dmg), '#ff5b5b', 22);
  for (let i = 0; i < 6; i++) spawnParticle(P.x, P.y - 45, rnd(-140, 140), rnd(-180, -30), 0.4, rnd(2, 4), '#ff4d4d', 400);
  if (P.hp <= 0) { P.hp = 0; P.dead = true; P.deadT = 0; G.phase = 'dead'; }
}

function aliveCount() {
  let n = 0;
  for (const e of enemies) if (e.on && !e.dead) n++;
  return n;
}

function handleTap(cx, cy) {
  const p = toWorld(cx, cy);
  if (G.phase === 'cards') {
    const cw = 250, gap = 40;
    const total = G.cards.length * cw + (G.cards.length - 1) * gap;
    let x = (VW - total) / 2;
    for (let i = 0; i < G.cards.length; i++) {
      if (p.x >= x && p.x <= x + cw && p.y >= 260 && p.y <= 560) { pickCard(i); return; }
      x += cw + gap;
    }
  } else if (G.phase === 'intro' || G.phase === 'dead') {
    startGame();
  }
}

// ---------- render ----------
function render() {
  if (bgDirty) buildBG();
  ctx.save();
  if (G.shake > 0) {
    const s = G.shake * 14;
    ctx.translate(rnd(-s, s), rnd(-s, s));
  }
  ctx.drawImage(bgCanvas, 0, 0);

  // clouds (parallax)

  // particles behind
  for (const p of particles) {
    if (!p.on) continue;
    const a = Math.max(0, p.life / p.max);
    ctx.globalAlpha = a;
    ctx.fillStyle = p.color;
    ctx.fillRect(p.x - p.size / 2, p.y - p.size / 2, p.size, p.size);
  }
  ctx.globalAlpha = 1;

  // enemies
  for (const e of enemies) {
    if (!e.on) continue;
    const sh = e.sheets;
    let name = sh.move;
    if (e.dead) name = sh.death || sh.move;
    else if (e.state === 'attack' && (sh.attack || sh.skill)) name = sh.attack || sh.skill;
    else if (e.flash > 0 && sh.hurt) name = sh.hurt;
    if (!name) continue;
    const a = ANIM[name];
    let frame = 0;
    if (a) {
      if (e.dead) frame = Math.min(a.count - 1, (e.animT * 12) | 0);
      else if (e.state === 'attack') frame = Math.min(a.count - 1, (e.animT * 14) | 0);
      else frame = (e.animT * 8) | 0;
    }
    const sc = e.sc * (e.boss ? 1 : 1);
    drawSheet(name, frame, e.x, e.y, sc, e.face < 0, e.dead ? 0.85 : 1);
    if (!e.dead && e.hp < e.maxHp) {
      const w = e.boss ? 130 : 56;
      ctx.fillStyle = 'rgba(0,0,0,0.55)';
      ctx.fillRect(e.x - w / 2, e.y - (e.boss ? 150 : 96), w, 7);
      ctx.fillStyle = e.boss ? '#ff5b5b' : '#7ee06b';
      ctx.fillRect(e.x - w / 2, e.y - (e.boss ? 150 : 96), w * (e.hp / e.maxHp), 7);
    }
  }

  // bullets
  for (const b of bullets) {
    if (!b.on) continue;
    const gimg = b.hostile ? GLOW_H : GLOW_P;
    const s2 = b.r * 2.4;
    ctx.drawImage(gimg, b.x - s2, b.y - s2, s2 * 2, s2 * 2);
  }

  // player
  if (!P.dead || P.deadT < 1.2) {
    const a = ANIM[P.anim];
    let frame = 0;
    if (a) {
      if (P.anim === 'hero_attack_1' || P.anim === 'hero_attack_2' || P.anim === 'hero_attack_3' || P.anim === 'hero_slz' || P.anim === 'hero_hytj')
        frame = Math.min(a.count - 1, (P.animT * 18) | 0);
      else frame = (P.animT * 8) | 0;
    }
    const blink = P.invuln > 0 && ((G.time * 20) | 0) % 2 === 0;
    drawSheet(P.anim, frame, P.x, P.y, 1.16, P.face < 0, blink ? 0.45 : 1);
  }

  // floaters
  for (const f of floaters) {
    if (!f.on) continue;
    ctx.globalAlpha = Math.min(1, f.life * 1.6);
    ctx.font = 'bold ' + f.size + 'px system-ui,-apple-system,sans-serif';
    ctx.textAlign = 'center';
    ctx.lineWidth = 4; ctx.strokeStyle = 'rgba(0,0,0,0.6)';
    ctx.strokeText(f.text, f.x, f.y);
    ctx.fillStyle = f.color;
    ctx.fillText(f.text, f.x, f.y);
    ctx.globalAlpha = 1;
  }
  ctx.textAlign = 'left';

  drawHUD();
  if (G.phase === 'cards') drawCards();
  if (G.phase === 'dead') drawGameOver();
  if (G.phase === 'intro') drawIntro();
  ctx.restore();
}

function drawHUD() {
  // backdrop
  ctx.fillStyle = 'rgba(8,14,24,0.45)';
  roundRect(14, 12, 356, 116, 12); ctx.fill();
  const bw = 320, bh = 20;
  ctx.fillStyle = 'rgba(0,0,0,0.5)';
  ctx.fillRect(24, 22, bw, bh); ctx.fillRect(24, 50, bw, 14);
  ctx.fillStyle = '#d63b3b';
  ctx.fillRect(24, 22, bw * clamp(P.hp / P.maxHp, 0, 1), bh);
  ctx.fillStyle = '#3b7bd6';
  ctx.fillRect(24, 50, bw * clamp(P.mp / P.maxMp, 0, 1), 14);
  ctx.strokeStyle = 'rgba(255,255,255,0.35)'; ctx.lineWidth = 2;
  ctx.strokeRect(24, 22, bw, bh); ctx.strokeRect(24, 50, bw, 14);
  ctx.fillStyle = '#fff'; ctx.font = 'bold 16px system-ui'; ctx.textAlign = 'left';
  ctx.fillText(Math.ceil(P.hp) + ' / ' + P.maxHp, 32, 38);
  ctx.fillStyle = '#ffe9b0'; ctx.font = 'bold 18px system-ui';
  ctx.fillText('第 ' + G.wave + ' 波', 26, 92);
  ctx.fillStyle = 'rgba(255,255,255,0.75)'; ctx.font = '15px system-ui';
  ctx.fillText('击杀 ' + G.killCount, 26, 116);

  // joystick
  if (touch.active) {
    ctx.globalAlpha = 0.35;
    ctx.beginPath(); ctx.arc(touch.joyOX, touch.joyOY, 60, 0, 6.283);
    ctx.fillStyle = 'rgba(255,255,255,0.25)'; ctx.fill();
    ctx.strokeStyle = 'rgba(255,255,255,0.6)'; ctx.lineWidth = 3; ctx.stroke();
    const dx = touch.joyX - touch.joyOX, dy = touch.joyY - touch.joyOY;
    const m = Math.min(60, Math.hypot(dx, dy));
    const k = m / (Math.hypot(dx, dy) || 1);
    ctx.beginPath(); ctx.arc(touch.joyOX + dx * k, touch.joyOY + dy * k, 28, 0, 6.283);
    ctx.fillStyle = 'rgba(255,220,120,0.85)'; ctx.fill();
    ctx.globalAlpha = 1;
  }

  // buttons
  for (const b of buttons) {
    const ready = b.cd <= 0;
    ctx.beginPath(); ctx.arc(b.x, b.y, b.r, 0, 6.283);
    ctx.fillStyle = b.on ? 'rgba(255,200,80,0.75)' : (ready ? 'rgba(30,40,60,0.55)' : 'rgba(30,40,60,0.3)');
    ctx.fill();
    ctx.strokeStyle = ready ? 'rgba(255,214,120,0.9)' : 'rgba(255,255,255,0.25)';
    ctx.lineWidth = 3; ctx.stroke();
    if (b.cd > 0) {
      ctx.beginPath();
      ctx.moveTo(b.x, b.y);
      ctx.arc(b.x, b.y, b.r, -Math.PI / 2, -Math.PI / 2 + b.cd * 6.283);
      ctx.closePath(); ctx.fillStyle = 'rgba(0,0,0,0.45)'; ctx.fill();
    }
    const ic = ICONS[b.id];
    if (ic && ic.width) {
      ctx.save();
      ctx.beginPath(); ctx.arc(b.x, b.y, b.r - 8, 0, 6.283); ctx.clip();
      ctx.globalAlpha = ready ? 1 : 0.45;
      const d = (b.r - 8) * 2;
      ctx.drawImage(ic, b.x - d / 2, b.y - d / 2, d, d);
      ctx.restore();
      ctx.globalAlpha = 1;
    } else {
      ctx.fillStyle = ready ? '#ffe9b0' : 'rgba(255,255,255,0.45)';
      ctx.font = 'bold ' + (b.r > 50 ? 26 : 15) + 'px system-ui';
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillText(b.label, b.x, b.y);
      ctx.textBaseline = 'alphabetic'; ctx.textAlign = 'left';
    }
  }
}

function drawCards() {
  ctx.fillStyle = 'rgba(6,10,18,0.72)';
  ctx.fillRect(0, 0, VW, VH);
  ctx.textAlign = 'center';
  ctx.fillStyle = '#ffe9b0'; ctx.font = 'bold 40px system-ui';
  ctx.fillText('选一张强化', VW / 2, 190);
  const cw = 250, ch = 300, gap = 40;
  const total = G.cards.length * cw + (G.cards.length - 1) * gap;
  let x = (VW - total) / 2;
  for (let i = 0; i < G.cards.length; i++) {
    const y = 260;
    const g = ctx.createLinearGradient(0, y, 0, y + ch);
    g.addColorStop(0, '#2a3b5c'); g.addColorStop(1, '#141d2e');
    ctx.fillStyle = g;
    roundRect(x, y, cw, ch, 18); ctx.fill();
    ctx.strokeStyle = '#7fa8d6'; ctx.lineWidth = 3; ctx.stroke();
    ctx.fillStyle = '#ffe9b0'; ctx.font = 'bold 26px system-ui';
    wrapText(G.cards[i].t, x + cw / 2, y + 120, cw - 40, 34);
    ctx.fillStyle = 'rgba(255,255,255,0.5)'; ctx.font = '16px system-ui';
    ctx.fillText('点 击 选 择', x + cw / 2, y + ch - 34);
    x += cw + gap;
  }
  ctx.textAlign = 'left';
}

function drawGameOver() {
  ctx.fillStyle = 'rgba(8,4,4,0.78)';
  ctx.fillRect(0, 0, VW, VH);
  ctx.textAlign = 'center';
  ctx.fillStyle = '#ff7a6b'; ctx.font = 'bold 64px system-ui';
  ctx.fillText('身 陨', VW / 2, 300);
  ctx.fillStyle = '#fff'; ctx.font = '26px system-ui';
  ctx.fillText('坚持到第 ' + G.wave + ' 波 · 击杀 ' + G.killCount, VW / 2, 370);
  ctx.fillStyle = '#ffe9b0'; ctx.font = '22px system-ui';
  ctx.fillText('点击屏幕重新开始', VW / 2, 450);
  ctx.textAlign = 'left';
}

function drawIntro() {
  ctx.fillStyle = 'rgba(6,10,18,0.82)';
  ctx.fillRect(0, 0, VW, VH);
  ctx.textAlign = 'center';
  ctx.fillStyle = '#ffe9b0'; ctx.font = 'bold 72px system-ui';
  ctx.fillText('造梦西游', VW / 2, 280);
  ctx.fillStyle = '#9fc4e8'; ctx.font = '24px system-ui';
  ctx.fillText('网页复刻 · 60FPS', VW / 2, 330);
  ctx.fillStyle = '#fff'; ctx.font = '20px system-ui';
  ctx.fillText('左侧拖动移动 · 右侧按钮释放技能', VW / 2, 400);
  ctx.fillStyle = 'rgba(255,255,255,0.55)'; ctx.font = '18px system-ui';
  ctx.fillText('点击屏幕开始', VW / 2, 470);
  ctx.textAlign = 'left';
}

function roundRect(x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}
function wrapText(text, cx, y, maxW, lh) {
  const chars = text.split('');
  let line = '', yy = y;
  for (const ch of chars) {
    if (ctx.measureText(line + ch).width > maxW) {
      ctx.fillText(line, cx, yy); line = ch; yy += lh;
    } else line += ch;
  }
  ctx.fillText(line, cx, yy);
}

// ---------- clicks for cards / restart ----------
cvs.addEventListener('click', e => {
  const p = toWorld(e.clientX, e.clientY);
  if (G.phase === 'cards') {
    const cw = 250, gap = 40;
    const total = G.cards.length * cw + (G.cards.length - 1) * gap;
    let x = (VW - total) / 2;
    for (let i = 0; i < G.cards.length; i++) {
      if (p.x >= x && p.x <= x + cw && p.y >= 260 && p.y <= 560) { pickCard(i); return; }
      x += cw + gap;
    }
  } else if (G.phase === 'intro') {
    startGame();
  } else if (G.phase === 'dead') {
    startGame();
  }
});

// ---------- main loop ----------
let last = performance.now(), acc = 0;
const STEP = 1 / 60;

function startGame() {
  P.x = 640; P.y = GROUND; P.vx = 0; P.vy = 0; P.onGround = true;
  P.hp = P.maxHp = 100; P.mp = P.maxMp = 100;
  P.atkMul = 1; P.cdMul = 1; P.lifesteal = 0; P.crit = 0.05; P.critMul = 2;
  P.dead = false; P.deadT = 0; P.dashCd = 0; P.fireCd = 0; P.stormCd = 0; P.atkCd = 0;
  P.anim = 'hero_rest'; P.animT = 0;
  G.wave = 0; G.killCount = 0; G.score = 0; G.spawnLeft = 0; G.waveT = 0;
  for (const e of enemies) e.on = false;
  for (const b of bullets) b.on = false;
  for (const p of particles) p.on = false;
  for (const f of floaters) f.on = false;
  startWave();
}

function loop(now) {
  const dt = Math.min(0.05, (now - last) / 1000);
  last = now;
  if (loaded) {
    acc += dt;
    let guard = 0;
    while (acc >= STEP && guard++ < 5) { update(STEP); acc -= STEP; }
    render();
  } else {
    ctx.fillStyle = '#0d1520'; ctx.fillRect(0, 0, VW, VH);
    ctx.fillStyle = '#9fc4e8'; ctx.font = '28px system-ui'; ctx.textAlign = 'center';
    ctx.fillText('载入中… ' + Math.round((1 - loadLeft / Math.max(1, Object.keys(SPR).length)) * 100) + '%', VW / 2, VH / 2);
    ctx.textAlign = 'left';
  }
  requestAnimationFrame(loop);
}

boot();
resize();
requestAnimationFrame(loop);
