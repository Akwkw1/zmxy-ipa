import UIKit
import SpriteKit

final class GameViewController: UIViewController {

    override func loadView() {
        let sk = SKView(frame: UIScreen.main.bounds)
        sk.backgroundColor = .black
        self.view = sk
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        guard let sk = view as? SKView else { return }
        sk.ignoresSiblingOrder = true
        sk.preferredFramesPerSecond = 60
        sk.isMultipleTouchEnabled = true
        let scene = GameScene(size: CGSize(width: 1280, height: 720))
        sk.presentScene(scene)
    }

    override var prefersStatusBarHidden: Bool { true }
    override var prefersHomeIndicatorAutoHidden: Bool { true }
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask { .landscape }
}
