# 造梦西游 · 原生 iOS 工程（SpriteKit）

**这是原生 App，不是网页。** 游戏逻辑与渲染全部用 Swift + SpriteKit 实现，
素材 100% 从你给的原版 APK 里抠出来（216 张精灵表、204 条动画定义、技能图标、背景）。

```
ios_port/
├── ZMXY.xcodeproj              ← 双击打开（含 scheme）
├── .github/workflows/build-ipa.yml  ← 没 Mac 也能出 ipa
├── Info.plist
├── Sources/
│   ├── AppDelegate.swift
│   ├── GameViewController.swift   ← SKView + 60fps
│   ├── GameScene.swift            ← 游戏主体（842 行）
│   └── www/assets/                ← 原版素材 16MB（folder reference）
└── README.md
```

---

## 关于「ipa 文件」

ipa = **编译产物 + 代码签名**。这台 iPad 上没有 Xcode / iOS SDK / 证书，
所以**我在这台设备上无法生成 ipa 文件**——这是设备能力边界，不是取舍。
工程已经做到「双击→Archive」的程度，下面三种方式任选：

### 方式 1：有 Mac（最快，3 分钟）

1. 双击 `ZMXY.xcodeproj`
2. target `ZMXY` → Signing & Capabilities → **Team** 选你的 Apple ID
3. Bundle Identifier 改成 `com.你的名字.zmxy`
4. Product → **Archive** → Distribute App → Development → 导出 `.ipa`
5. Sideloadly / AltStore 装到手机

免费 Apple ID：7 天有效期；付费账号：1 年。

### 方式 2：没有 Mac（GitHub Actions 自动编译）

1. 把 `ios_port/` 里的**全部内容**作为一个新仓库上传到 GitHub
   （`.github` 目录要一起传，它决定了自动编译）
2. 仓库 → Actions → `Build unsigned IPA` → Run workflow
3. 跑完在 Artifacts 里下载 **ZMXY-unsigned-ipa**
4. 用 **Sideloadly**（Windows / Mac 都能装）打开这个 ipa，
   填自己的 Apple ID → 它会用你的证书重签并装到手机

> 这一步不需要 Mac，只需要 Windows 电脑 + 数据线 + 一个 Apple ID。

### 方式 3：现在就想看效果

本机已跑着服务：Safari 打开 `http://127.0.0.1:8766/index.html`
（同一套逻辑的 Web 版，用来验证画面/手感；素材完全相同）

---

## 游戏内容

- **22 个角色族**：hero + 天兵鸟、刀兵、弓兵、枪兵、狗妖、羊妖、牛妖、蛇精、蜈蚣精、黑虎、黑龟
  + 精英（千里眼/顺风耳/无影/哮天犬）+ Boss（巨灵神/南天王/北天王/西天王/朱子真/杨戬/袁洪）
- **动画**：直接用原版 `animations.json` 的帧宽高/列数/脚部锚点切帧
- **技能**：跳、烈焰闪（冲刺无敌）、火眼（穿透火球）、升龙（AOE），图标取自原版 `skill_icons`
- **背景**：原版 `clouds.webp` 云海 + `arena_platform.webp` 石台
- **系统**：波次递增、每 3 波三选一强化卡、每 5 波 Boss

## 性能

- SpriteKit 原生渲染，60fps
- 精灵动画用 `SKAction.animate` 预切帧，无运行时分配
- 对象复用（敌人/子弹池）

## 必须说明的风险

这台设备**不能编译 Swift**，所以 `GameScene.swift` **没有经过编译器验证**。
逻辑与 API 都是按 SpriteKit 标准写法写的，但首次 build 可能出现少量编译错误
（类型推断、可选值解包之类），在 Xcode 里按提示改几行即可。

如果你要「一次就能编译通过」的稳方案，用之前的 **WKWebView 壳**
（`ios_port-webview/`，逻辑跑 JS，已验证 58fps），那个几乎不会出错。
